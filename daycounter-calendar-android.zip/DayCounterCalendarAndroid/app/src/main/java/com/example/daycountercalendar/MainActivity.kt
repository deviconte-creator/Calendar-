package com.example.daycountercalendar

import android.os.Bundle
import android.widget.CalendarView
import androidx.appcompat.app.AppCompatActivity
import com.example.daycountercalendar.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Modes: true -> compare selected date to Today; false -> between two selected dates
    private var modeToday = true
    private var firstDate: Long? = null

    private val dateFmt = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.topAppBar.title = getString(R.string.app_name)

        val calendarView = binding.calendarView
        calendarView.setOnDateChangeListener { _: CalendarView, year: Int, month: Int, dayOfMonth: Int ->
            val cal = Calendar.getInstance()
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, month)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            val selectedMillis = cal.timeInMillis
            val selectedDate = Date(selectedMillis)

            binding.selectedDateText.text = dateFmt.format(selectedDate)

            if (modeToday) {
                val diffDays = daysBetween(selectedMillis, todayMidnightMillis())
                when {
                    diffDays == 0L -> binding.diffText.text = getString(R.string.today)
                    selectedMillis < todayMidnightMillis() -> {
                        binding.diffText.text = formatDaysAgo(diffDays)
                    }
                    else -> {
                        binding.diffText.text = formatInDays(diffDays)
                    }
                }
            } else {
                // between two selected dates
                if (firstDate == null) {
                    firstDate = selectedMillis
                    binding.modeHint.text = getString(R.string.mode_hint_between)
                    binding.diffText.text = "Первая дата: ${dateFmt.format(Date(firstDate!!))}. Выберите вторую дату."
                } else {
                    val second = selectedMillis
                    val d = daysBetween(firstDate!!, second)
                    val text = getString(
                        R.string.between_days,
                        dateFmt.format(Date(firstDate!!)),
                        dateFmt.format(Date(second)),
                        d,
                        pluralizeDays(d)
                    )
                    binding.diffText.text = text
                    firstDate = null
                }
            }
        }

        binding.modeFab.setOnClickListener {
            modeToday = !modeToday
            firstDate = null
            binding.modeHint.text = if (modeToday) getString(R.string.mode_hint_today) else getString(R.string.mode_hint_between)
            // Reset helper text
            binding.diffText.text = if (modeToday) getString(R.string.diff_default) else "Выберите дату А, затем дату Б."
        }
    }

    private fun todayMidnightMillis(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun daysBetween(a: Long, b: Long): Long {
        val diff = abs(a - b)
        return diff / (24L * 60L * 60L * 1000L)
    }

    private fun pluralizeDays(n: Long): String {
        // Russian pluralization for "день/дня/дней"
        val nMod10 = (n % 10).toInt()
        val nMod100 = (n % 100).toInt()
        return when {
            nMod10 == 1 && nMod100 != 11 -> "день"
            nMod10 in 2..4 && (nMod100 < 10 || nMod100 >= 20) -> "дня"
            else -> "дней"
        }
    }

    private fun formatDaysAgo(n: Long): String {
        return String.format(Locale.getDefault(), getString(R.string.days_ago), n, pluralizeDays(n))
    }

    private fun formatInDays(n: Long): String {
        return String.format(Locale.getDefault(), getString(R.string.in_days), n, pluralizeDays(n))
    }
}